1. Drag the "ConEmu" folder into your "C:\Program Files\" directory
2. Find the Bash shortcut here: "C:\Program Files\ConEmu\Bash"
3. Right-click Bash
    a. Pin to Start
    b. Pin to taskbar

You should now see Bash in your start menu and in your taskbar.